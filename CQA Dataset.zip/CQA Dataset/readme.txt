This folder contains

TitleUnescaped.csv - contains the titles of the questions, and the labels:

1 - Conversational
0 - Informational

descr.tsv - file with the descriptions of the answers
Allanswersunescaped.csv - contains all answers that are related to a given question
Bestanswerunescaped.csv - contains the best answer

The files are of different size because the only mandatory text for each entry is the questions’s title. The description, answer and the best answer are optional. The first field in each file is the question ID.

